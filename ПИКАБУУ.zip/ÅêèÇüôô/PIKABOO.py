import sys, os, pygame, random
from pygame.locals import *

# Начальные координаты Пикачу (персонажа, за которого играем мы)
x_coord = 1
y_coord = 320
# Начальная скорость Пикачу
x_speed = 0
y_speed = 0
# Количество жизненной энергии Пикачу
score = 1000
# Счётчик, определяющий, когда противники изменяют направление движения
change = 0
# Сдвиги по вертикали для противников
go1 = 0
go2 = 0
go3 = 0

pygame.init()
# Создаём игровое окно 550*500
window = pygame.display.set_mode((550, 500))
# Ставим свой заголовок окна,
# т. е. название игры
pygame.display.set_caption('PIKABOO')
pygame.mixer.music.load('song.mp3')
pygame.mixer.music.play()
info = pygame.Surface((800, 30))
# Получаем поверхность, на которой будем рисовать
screen = pygame.display.get_surface()

class Menu:
    def __init__(self, punkts):
        self.punkts = punkts

    def render(self, poverhnost, font, num_punkt):
        for i in self.punkts:
            if num_punkt == i[5]:
                poverhnost.blit(font.render(i[2], 1, i[4]), (i[0], i[1] - 30))
            else:
                poverhnost.blit(font.render(i[2], 1, i[3]), (i[0], i[1] - 30))

    def menu(self):
        font_menu = pygame.font.Font(None, 50)
        pygame.key.set_repeat(0, 0)
        pygame.mouse.set_visible(True)
        punkt = 0
        running = True
        while running:
            info.fill(((0, 184, 217)))
            screen.fill(((0, 184, 217)))
            mp = pygame.mouse.get_pos()
            for i in self.punkts:
                if mp[0] > i[0] and mp[0] < i[0] + 155 and mp[1] > i[1] and mp[1] < i[1] + 50:
                    punkt = i[5]
            self.render(screen, font_menu, punkt)
            for e in pygame.event.get():
                if e.type == pygame.QUIT:
                    sys.exit()
                if e.type == pygame.KEYDOWN:
                    if e.key == pygame.K_ESCAPE:
                        sys.exit()
                    if e.key == pygame.K_UP:
                        if punkt > 0:
                            punkt -= 1
                    if e.key == pygame.K_DOWN:
                        if punkt < len(self.punkts) - 1:
                            punkt += 1
                if e.type == pygame.MOUSEBUTTONDOWN and e.button == 1:
                    if punkt == 0:
                        running = False
                    elif punkt == 1:
                        exit()
            window.blit(info, (0, 0))
            window.blit(screen, (0, 30))
            pygame.display.flip()



def load_image(name, colorkey=None):
    # Добавляем к имени картинки имя папки
    # где находятся изображения
    fullname = os.path.join('kartin', name)
    # Загружаем картинку
    image = pygame.image.load(fullname)
    image = image.convert()
    # Если второй параметр =-1 делаем прозрачным
    # цвет из точки 0,0
    if colorkey is not None:
        if colorkey is -1:
            colorkey = image.get_at((0, 0))
        image.set_colorkey(colorkey, RLEACCEL)
    return image, image.get_rect()


def draw_background():
    # И размер этой поверхности
    background = pygame.Surface(screen.get_size())
    background = background.convert()
    # Загружаем картинку заднего фона
    back, back_rect = load_image("back.jpg")
    # и рисуем ее
    screen.blit(back, (0, 0))
    # переключаем буфер экрана
    pygame.display.flip()
    return back


# Класс описывающий летающищие объекты
class Flying(pygame.sprite.Sprite):
    def __init__(self, kart, cX, cY):
        # Создаем спрайт из картинки
        pygame.sprite.Sprite.__init__(self)
        self.image, self.rect = load_image(kart, -1)
        screen = pygame.display.get_surface()
        self.area = screen.get_rect()
        # Перемещаем картинку в её начальные координаты
        self.rect.x = cX
        self.rect.y = cY


# Создаём класс Pikachu
# он наследуется от предыдущего класса
class Pikachu(Flying):
    def __init__(self, cX, cY):
        Flying.__init__(self, "pikachu.png", cX, cY)


# Создаём класс Evil,
# который так же наследуется от класса Flying
class Evil(Flying):
    def __init__(self, cX, cY):
        Flying.__init__(self, "evil.png", cX, cY)


def input(events):
    global x_coord, y_coord, x_speed, y_speed, life
    # Перехватываем нажатия клавиш на клавиатуре
    for event in events:
        if (event.type == QUIT) or (event.type == KEYDOWN and event.key == K_ESCAPE):
            pygame.quit()
            sys.exit()
        # Когда нажаты стрелки изменяем скорость Пикачу
        # чтобы он летел
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_LEFT:
                x_speed = -1
            if event.key == pygame.K_RIGHT:
                x_speed = 1
            if event.key == pygame.K_UP:
                y_speed = -1
            if event.key == pygame.K_DOWN:
                y_speed = 1
        # Когда стрелки не нажаты скорость равна нулю
        if event.type == pygame.KEYUP:
            if event.key == pygame.K_LEFT:
                x_speed = 0
            if event.key == pygame.K_RIGHT:
                x_speed = 0
            if event.key == pygame.K_UP:
                y_speed = 0
            if event.key == pygame.K_DOWN:
                y_speed = 0
    # Делаем границы поля,
    # чтобы Пикачу не выходил за рамки при любой скорости
    x_coord = x_coord + x_speed
    y_coord = y_coord + y_speed
    if (x_coord < 0):
        x_coord = 0
    if (x_coord > 430):
        x_coord = 430
    if (y_coord < 0):
        y_coord = 0
    if (y_coord > 320):
        y_coord = 320


def action(draw_fon):
    global x_coord, y_coord, score, change, go1, go2, go3
    screen = pygame.display.get_surface()
    # Создаём Пикачу и противников
    pika = Pikachu(1, 320)
    evil1 = Evil(500, 100)
    evil2 = Evil(800, 200)
    evil3 = Evil(1200, 350)
    # Добавляем их в два массива
    ev = []
    ev.append(evil1)
    ev.append(evil2)
    ev.append(evil3)
    air = []
    air.append(pika)
    # Рисуем их
    evils = pygame.sprite.RenderPlain(ev)
    pikachs = pygame.sprite.RenderPlain(air)
    timer = pygame.time.Clock()
    # Запускаем бесконечный цикл
    running = True
    while running:
        # Создаем паузу
        timer.tick(700)
        # Ждём нажатия клавиш
        input(pygame.event.get())
        # Проверяем столкновения
        blocks_hit_list = pygame.sprite.spritecollide(pika, evils, False)
        # Если есть столкновения уменьшаем жизненную энергию
        if len(blocks_hit_list) > 0:
            score -= len(blocks_hit_list)
            evils.draw(screen)
            pikachs.draw(screen)
            if (score < 1):
                pygame.quit()
                sys.exit(0)
        # Обновляем координаты Пикачу
        pika.rect.x = x_coord
        pika.rect.y = y_coord
        # Изменяем положение противников
        evil1.rect.x = evil1.rect.x - 1
        evil2.rect.x = evil2.rect.x - 1
        evil3.rect.x = evil3.rect.x - 1
        if (evil1.rect.x < 0):
            evil1.rect.x = 500
            evil1.rect.y = 100
        if (evil2.rect.x < 0):
            evil2.rect.x = 800
            evil2.rect.y = 200
        if (evil3.rect.x < 0):
            evil3.rect.x = 1200
            evil3.rect.y = 350
        # Раз в 300 итераций противники
        # изменяют  своё направление движения
        if (change > 300):
            change = 0
            go1 = random.randint(-1, 1)
            go2 = random.randint(-1, 1)
            go3 = random.randint(-1, 1)
        evil1.rect.y += go1
        evil2.rect.y += go2
        evil3.rect.y += go3
        change += 1
        # Заново прорисовываем объекты
        screen.blit(draw_fon, (0, 0))
        font = pygame.font.Font(None, 25)
        black = (0, 0, 0)
        life = int(score / 10)
        text = font.render("Энергия: " + str(life), True, black)
        # Рисуем надпись с жизнями
        screen.blit(text, [10, 10])
        # Обновляем положение объектов
        evils.update()
        pikachs.update()
        # Обновляем кадр
        evils.draw(screen)
        pikachs.draw(screen)
        pygame.display.flip()
    pygame.quit()

# Создаём начальное меню с пунктами начала игры и выхода из неё
pygame.font.init()
punkts = [(250, 200, u'Играть', (15, 20, 57), (255, 179, 0), 0),
(250, 240, u'Выход', (15, 20, 57), (255, 179, 0), 1)]
game = Menu(punkts)
game.menu()

def main():
    draw_fon = draw_background()
    action(draw_fon)

main()
